package Controlador;

import Models.Producto;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class Principal extends javax.swing.JFrame {
    //Variables globales
    DefaultTableModel modelo = new DefaultTableModel();
    ArrayList<Producto> listaProductos = new ArrayList<>();
    int xcodprod;
    String xnomprod;
    String xcateprod;
    double xpreprod;
    int xcanprod;
    double xtotal;
    int filaSeleccionada;

    public Principal() {
          initComponents();
        modelo.addColumn("Codigo");
        modelo.addColumn("Descripcion");
        modelo.addColumn("Categoria");
        modelo.addColumn("Precio");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Total");
        
        tblSalida.setModel(modelo); 
        
        // Definir un arreglo de productos
        Producto[] productos = {
            new Producto(1, "Camiseta", "C" , 20.50, 2, 20.50 * 2),
            new Producto(2, "Pantalón", "P" , 35.99, 1, 35.99 * 1),
            new Producto(3, "Zapatos", "Z", 49.99, 1, 49.99 * 1),
            new Producto(4, "Chaqueta", "C", 70.00, 3, 70.00 * 3),
            new Producto(5, "Gorro", "G" , 15.00, 5, 15.00 * 5)
        };
        
        // Agregar productos al ArrayList y a la tabla
        for (Producto producto : productos) {
            listaProductos.add(producto);
            modelo.addRow(new Object[]{
                producto.getCodprod(),
                producto.getDesprod(),
                producto.getCateprod(),
                producto.getPreprod(),
                producto.getCanprod(),
                producto.getTotprod()
            });
        }
        
        // Actualizar totales
        actualizarTotales();
    }


    @SuppressWarnings("unchecked")
    
    
private void actualizarTotales() {
    int cantidadTotal = listaProductos.size(); 
    double totalPago = 0.0;

    // Recorrer la lista de productos para sumar el total
    for (Producto prod : listaProductos) {
        totalPago += prod.getTotprod();
    }

    // Mostrar los totales actualizados en los campos de texto
    txtCantidadTotal.setText(String.valueOf(cantidadTotal));  // Total de filas
    txtTotalPago.setText(Double.toString(totalPago));  // Total a pagar sin formatear a decimales
//listaProductos.size() pa sumar el numero de fila
}
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtNomprod = new javax.swing.JTextField();
        txtPreprod = new javax.swing.JTextField();
        txtCanprod = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        btnAgregar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSalida = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel7 = new javax.swing.JLabel();
        txtCantidadTotal = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtTotalPago = new javax.swing.JTextField();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        txtCodprod = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtCate = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtCateprod = new javax.swing.JTextField();
        btnProd = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SISTEMA DE COMPRAS");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("REGISTROS DE PRODUCTOS");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Codigo :");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Nombre :");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Precio :");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Cantidad :");

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jScrollPane1.setViewportView(tblSalida);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("REPORTE DE PRODUCTOS");

        jLabel7.setText("Cantidad de Productos");

        txtCantidadTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadTotalActionPerformed(evt);
            }
        });

        jLabel8.setText("Total a pagar :");

        jLabel9.setText("Buscar por categoria:");

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        jLabel10.setText("Categoria:");

        btnProd.setText("Productos");
        btnProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProdActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(304, 304, 304)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jSeparator3)
                                        .addComponent(jSeparator2)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel10)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGap(31, 31, 31)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(txtPreprod)
                                                .addComponent(txtCanprod)
                                                .addComponent(txtCateprod, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE))
                                        .addGap(31, 31, 31)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtNomprod)
                                            .addComponent(txtCodprod, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE))))
                                .addGap(37, 37, 37)
                                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(jSeparator7, javax.swing.GroupLayout.DEFAULT_SIZE, 1, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jSeparator5, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 424, Short.MAX_VALUE))
                                        .addGap(35, 35, 35)
                                        .addComponent(jSeparator6))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel7)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(txtCantidadTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel8)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(txtTotalPago, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 424, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btnProd))
                                        .addGap(0, 36, Short.MAX_VALUE))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCate, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBuscar)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(48, 48, 48))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel6))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(159, 159, 159)
                                        .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(txtCantidadTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel8)
                                        .addComponent(txtTotalPago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel7))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnProd))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2)
                                    .addComponent(txtCodprod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(txtNomprod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(txtCateprod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(txtPreprod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(txtCanprod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnAgregar)
                                    .addComponent(btnEditar)
                                    .addComponent(btnModificar)
                                    .addComponent(btnEliminar))
                                .addGap(13, 13, 13)
                                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtCate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar))))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        if (txtCodprod.getText().isEmpty() || txtNomprod.getText().isEmpty() ||
        txtPreprod.getText().isEmpty() || txtCanprod.getText().isEmpty()) {
        
        // Mostrar alerta de falta de datos
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.", 
                                                  "Datos incompletos", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;  // Salir del método si faltan datos
    }
        // Entrada o leer datos del formulario
        xcodprod = Integer.parseInt(txtCodprod.getText());
        xnomprod = txtNomprod.getText();
        xcateprod = txtCateprod.getText();
        xpreprod = Double.parseDouble(txtPreprod.getText());
        xcanprod = Integer.parseInt(txtCanprod.getText());
        xtotal = xpreprod * xcanprod;
        
        // Crear un objeto producto de la clase Producto
        Producto producto = new Producto(xcodprod,xnomprod,xcateprod,xpreprod,xcanprod,xtotal);
        
        // Agregar el objeto producto al arreglo lista productos
        listaProductos.add(producto);
        
        // listaProductos = {objeto1,objeto2,objeto3}
        // objeto = {cod,des,pre,cant}
        // Agregar el objeto a la tabla
        Object objeto[] = new Object[6];
        for(int x=0;x<listaProductos.size();x++){
            objeto[0] = listaProductos.get(x).getCodprod();
            objeto[1] = listaProductos.get(x).getDesprod();
            objeto[2] = listaProductos.get(x).getCateprod();
            objeto[3] = listaProductos.get(x).getPreprod();
            objeto[4] = listaProductos.get(x).getCanprod();
            objeto[5] = listaProductos.get(x).getTotprod();
        }
        modelo.addRow(objeto);
        
        int cantidadTotal = 0;
    double totalPago = 0.0;
    
    // Recorrer la lista de productos para sumar la cantidad y el total
    for (Producto prod : listaProductos) {
        cantidadTotal += prod.getCanprod();
        totalPago += prod.getTotprod();
    }

    // Mostrar los totales actualizados en los campos de texto
    txtCantidadTotal.setText(String.valueOf(cantidadTotal));  // Cantidad total de productos
    txtTotalPago.setText(Double.toString(totalPago));  // Total a pagar sin formatear a decimales

    txtCodprod.setText("");
    txtNomprod.setText("");
    txtCateprod.setText("");
    txtPreprod.setText("");
    txtCanprod.setText("");
    
    txtCodprod.requestFocus();
    actualizarTotales();
        
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
     // Obtener la fila seleccionada
    filaSeleccionada = tblSalida.getSelectedRow(); 

// Verificar si se ha seleccionado una fila
if (filaSeleccionada == -1) {
    // Mostrar alerta si no hay fila seleccionada
    javax.swing.JOptionPane.showMessageDialog(this, 
        "Por favor, seleccione un producto para eliminar.", 
        "Sin selección", 
        javax.swing.JOptionPane.WARNING_MESSAGE);
    return;  // Salir del método si no hay selección
}


// Eliminar de la tabla
modelo.removeRow(filaSeleccionada);

// Eliminar de la lista de productos
listaProductos.remove(filaSeleccionada);

// Opcional: Actualizar la cantidad total y el total a pagar
actualizarTotales();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        filaSeleccionada = tblSalida.getSelectedRow(); // Obtener la fila seleccionada

    // Verificar si se ha seleccionado una fila
    if (filaSeleccionada == -1) {
        // Mostrar alerta si no hay fila seleccionada
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione un producto para modificar.", 
                                                  "Sin selección", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;  // Salir del método si no hay selección
    }

    // Modificar
    xcodprod = Integer.parseInt(txtCodprod.getText());
    xnomprod = txtNomprod.getText();
    xcateprod = txtCateprod.getText();
    xpreprod = Double.parseDouble(txtPreprod.getText());
    xcanprod = Integer.parseInt(txtCanprod.getText());
    xtotal = xpreprod * xcanprod;

    // Actualizar la fila seleccionada en la tabla
    modelo.setValueAt(xcodprod, filaSeleccionada, 0);
    modelo.setValueAt(xnomprod, filaSeleccionada, 1);
    modelo.setValueAt(xcateprod, filaSeleccionada, 2);
    modelo.setValueAt(xpreprod, filaSeleccionada, 3);
    modelo.setValueAt(xcanprod, filaSeleccionada, 4);
    modelo.setValueAt(xtotal, filaSeleccionada, 5);

    // Actualizar la lista de productos para mantenerla sincronizada
    Producto producto = listaProductos.get(filaSeleccionada);
    producto.setCodprod(xcodprod);
    producto.setDesprod(xnomprod);
    producto.setCateprod(xcateprod);
    producto.setPreprod(xpreprod);
    producto.setCanprod(xcanprod);
    producto.setTotprod(xtotal);

    // Limpiar los campos de entrada
    txtCodprod.setText("");
    txtNomprod.setText("");
    txtPreprod.setText("");
    txtCanprod.setText("");
    txtCateprod.setText("");

    txtCodprod.requestFocus();
    actualizarTotales();
        
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // Editar
         filaSeleccionada = tblSalida.getSelectedRow(); // Obtener la fila seleccionada

    // Verificar si se ha seleccionado una fila
    if (filaSeleccionada == -1) {
        // Mostrar alerta si no hay fila seleccionada
        javax.swing.JOptionPane.showMessageDialog(this, "Por favor, seleccione un producto para editar.", 
                                                  "Sin selección", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;  // Salir del método si no hay selección
    }

    // Cargar los datos del producto seleccionado en los campos de texto
    txtCodprod.setText(modelo.getValueAt(filaSeleccionada, 0).toString());
    txtNomprod.setText(modelo.getValueAt(filaSeleccionada, 1).toString());
    txtCateprod.setText(modelo.getValueAt(filaSeleccionada, 2).toString());
    txtPreprod.setText(modelo.getValueAt(filaSeleccionada, 3).toString());
    txtCanprod.setText(modelo.getValueAt(filaSeleccionada, 4).toString());
    
    actualizarTotales();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
    String categoriaBuscada = txtCate.getText().trim();  // Obtener la categoría del campo de texto
    
      if (categoriaBuscada.isEmpty()) {
        // Mostrar alerta si el campo está vacío
        javax.swing.JOptionPane.showMessageDialog(this, 
            "Por favor, ingrese una categoría para buscar.", 
            "Categoría Vacía", 
            javax.swing.JOptionPane.WARNING_MESSAGE);
        return;  // Salir del método si está vacío
    }
      
    DefaultTableModel modeloBusqueda = new DefaultTableModel(); // Crear un nuevo modelo de tabla

    // Agregar columnas al modelo de búsqueda
    modeloBusqueda.addColumn("Codigo");
    modeloBusqueda.addColumn("Descripcion");
    modeloBusqueda.addColumn("Categoria");
    modeloBusqueda.addColumn("Precio");
    modeloBusqueda.addColumn("Cantidad");
    modeloBusqueda.addColumn("Total");

    // Filtrar productos por categoría
    for (Producto producto : listaProductos) {
        if (producto.getCateprod().equalsIgnoreCase(categoriaBuscada)) {
            // Agregar solo los productos que coincidan con la categoría buscada
            modeloBusqueda.addRow(new Object[]{
                producto.getCodprod(),
                producto.getDesprod(),
                producto.getCateprod(),
                producto.getPreprod(),
                producto.getCanprod(),
                producto.getTotprod()
            });
        }
    }

    // Actualizar la tabla con los resultados de búsqueda
    tblSalida.setModel(modeloBusqueda);

    // Limpiar el campo de búsqueda
    txtCate.setText("");
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProdActionPerformed
    DefaultTableModel modeloCompleto = new DefaultTableModel();
    
    // Agregar columnas al modelo completo
    modeloCompleto.addColumn("Codigo");
    modeloCompleto.addColumn("Descripcion");
    modeloCompleto.addColumn("Categoria");
    modeloCompleto.addColumn("Precio");
    modeloCompleto.addColumn("Cantidad");
    modeloCompleto.addColumn("Total");

    // Agregar todos los productos de la lista al modelo completo
    for (Producto producto : listaProductos) {
        modeloCompleto.addRow(new Object[]{
            producto.getCodprod(),
            producto.getDesprod(),
            producto.getCateprod(),
            producto.getPreprod(),
            producto.getCanprod(),
            producto.getTotprod()
        });
    }

    // Actualizar la tabla con el modelo completo
    tblSalida.setModel(modeloCompleto);
    actualizarTotales();
    }//GEN-LAST:event_btnProdActionPerformed

    private void txtCantidadTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCantidadTotalActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnProd;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JTable tblSalida;
    private javax.swing.JTextField txtCanprod;
    private javax.swing.JTextField txtCantidadTotal;
    private javax.swing.JTextField txtCate;
    private javax.swing.JTextField txtCateprod;
    private javax.swing.JTextField txtCodprod;
    private javax.swing.JTextField txtNomprod;
    private javax.swing.JTextField txtPreprod;
    private javax.swing.JTextField txtTotalPago;
    // End of variables declaration//GEN-END:variables
}
