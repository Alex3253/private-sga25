package Models;

public class Producto {
    //Atributos privados
    private int codprod;
    private String desprod;
    private String cateprod;
    private double preprod;
    private int canprod;
    private double totprod;
    
    //Constructor de parametros
    public Producto(int codprod, String desprod,String cateprod, double preprod, int canprod, double totprod) {
        this.codprod = codprod;
        this.desprod = desprod;
        this.cateprod = cateprod;
        this.preprod = preprod;
        this.canprod = canprod;
        this.totprod = totprod;
    }

    public Producto(int i, String producto_C, double d, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getCodprod() {
        return codprod;
    }

    public void setCodprod(int codprod) {
        this.codprod = codprod;
    }

    public String getDesprod() {
        return desprod;
    }

    public void setDesprod(String desprod) {
        this.desprod = desprod;
    }

    public String getCateprod() {
        return cateprod;
    }

    public void setCateprod(String cateprod) {
        this.cateprod = cateprod;
    }

    public double getPreprod() {
        return preprod;
    }

    public void setPreprod(double preprod) {
        this.preprod = preprod;
    }

    public int getCanprod() {
        return canprod;
    }

    public void setCanprod(int canprod) {
        this.canprod = canprod;
    }

    public double getTotprod() {
        return totprod;
    }

    public void setTotprod(double totprod) {
        this.totprod = totprod;
    }
    
    

    
}
